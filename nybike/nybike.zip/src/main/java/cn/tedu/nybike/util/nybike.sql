-- 创建数据库
create database nybikedb;

-- 使用库
use nybikedb;

-- 创建表
create table tb_trip_1904(
tripduration int,
starttime char(26),
stoptime char(26),
start_station_id int,
start_station_name varchar(255),
start_station_latitude double,
start_station_longtitude double,
end_station_id int,
end_station_name varchar(255),
end_station_latitude double,
end_station_longtitude double,
bikeid int,
usertype char(12),
birth_year int,
gender tinyint
)default charset utf8;

-- 查看当前库下所有表
show tables;

-- 查看一个表的字段和数据类型
desc tb_trip_1904;

-- 查看一张表的建表语句
show create table tb_trip_1904;

-- 查询表中的数据数量
select count(*) from tb_trip_1904;

-- 将csv数据导入数据库表
load data infile 'D:/201904-citibike-tripdata.csv' -- 文件的绝对路径
into table tb_trip_1904 -- 表名
fields terminated by ',' -- 原始文件中的分隔符
optionally enclosed by '"' -- 去掉原始数据前后的双引号
ignore 1 lines; -- 导入时忽略第一行-表头行


